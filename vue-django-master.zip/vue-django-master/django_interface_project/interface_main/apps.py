from django.apps import AppConfig


class InterfaceMainConfig(AppConfig):
    name = 'interface_main'
