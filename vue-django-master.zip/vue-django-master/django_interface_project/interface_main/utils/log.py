import logging

log = logging.getLogger('interface')
default_log = log